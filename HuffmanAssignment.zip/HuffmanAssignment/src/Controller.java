import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import javax.xml.ws.FaultAction;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    private HuffmanCode hc;

    private ArrayList<Node> array;

    //Bugs: If only one letter is input an IndexOutOfBoundsException is caught
    //also X is depicted as null rather than getting a binary value and W is depicted as X sometimes? :S

    @FXML
    private TextField inputField;
    @FXML
    private TextArea  textArea;
    @FXML
    private Label welcomeHeadline;

    public void readFromFile(ActionEvent event) throws IOException, ClassNotFoundException {
        hc.readFileInput();
        theSetup();
    }

    public void readFromInput(ActionEvent event) throws IOException{
        hc.setMessage(inputField.getText());
        theSetup();
    }

    public void theSetup() throws IOException {
        array = hc.generateArray();
        array = hc.binaryTree(array);
        hc.writeInFile(hc.writeCodeMessage(array));
        textArea.setText("Binary decryption table: \n" + hc.getBinaryValues() + "Binary encrypted message: " + hc.writeCodeMessage(array));
        hc.clearBinaryValues();
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        hc = new HuffmanCode();
        array = new ArrayList();
//        try {
//            array = hc.generateArray();
//            array = hc.binaryTree(array);
//            String message = hc.writeCodeMessage(array);
//            hc.writeInFile(message);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }
}
