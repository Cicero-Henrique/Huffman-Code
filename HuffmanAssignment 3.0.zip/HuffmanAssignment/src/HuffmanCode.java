// MISSISSIPI RIVER

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class HuffmanCode 
{
    private String text = "";
    private String binaryValues = "";

    public void setMessage(String userInput){
        text = userInput;
    }

    public String getMessage()
    {
        return text;
    }

    public String getBinaryValues(){
        return binaryValues;
    }

    public void clearBinaryValues(){
        binaryValues = "";
    }

    
    public ArrayList<Node> bubbleSortTree(ArrayList<Node> array) // Sort the array of nodes 
    {
        Node temp;
        for (int i = 0; i < array.size(); i++) 
        {
            for (int j = 1; j < (array.size() - i); j++) 
            {
                if (array.get(j-1).getNum() < array.get(j).getNum()) 
                {
                    temp = array.get(j-1);
                    array.set(j-1, array.get(j));
                    array.set(j, temp);
                }
            }
        }
        return array;
    }
    

    public ArrayList<Node> hashMap(String message)
    {
        String key;
        Map<String, Node> map = new HashMap<>();
        ArrayList<Node> array =  new ArrayList<>();
        ArrayList<String> letters =  new ArrayList();

        for (int i = 0; i < message.length(); i++) 
        {
            key = Character.toString(message.charAt(i));
            if (map.get(key) == null) 
            {
                Node n = new Node();
                n.setLetter(key);
                n.setNum(1);
                map.put(key, n);
                letters.add(key);
            } 
            else 
                map.get(key).setNum(map.get(key).getNum() + 1);
        }
        for(int i = 0; i < letters.size(); i++)
            array.add(map.get(letters.get(i)));
        
        return array ;
    }

    public ArrayList<Node> generateArray() throws IOException 
    {
        String message = getMessage();                              //Get the String on the file but now I'm using "mississippi river" just for tests 
        ArrayList<Node> array;                                      
        QuickSort qs = new QuickSort();                             
                                                                    
        array = hashMap(message);                                   //Create the array with all letters that the word have
        qs.sort(array, 0, array.size() -1);                         //Sort the array of Integers
        return array;
    }
    
    public Node createRoot(Node r, Node l1, Node l2)
    {
        r.setLetter(l1.getLetter() + l2.getLetter());
        r.setNum(l1.getNum() + l2.getNum());
        l1.setAux(0);
        l2.setAux(1);
        r.setLeft(l1);
        r.setRight(l2);
        return r;
    }
    
    public void generateBinaries(Node n, String side, String sc)
    {
        if(n!= null)
        {
            n.setBinarie((n.getBinarie() +sc + side).trim());
            if(n.getLetter().length() == 1)
            {
                binaryValues += "Letter: " + n.getLetter() + ". Num of Occurrences: " + n.getNum() + ". Binary Value: " + n.getBinarie() + "\n";
                //System.out.println(n.getLetter() + "-" + n.getNum()+"-"+n.getBinarie()+";");
            }
            generateBinaries(n.getLeft(), "0", n.getBinarie());
            generateBinaries(n.getRight(), "1", n.getBinarie());
        }
    }
    
    public ArrayList<Node> generateTree(ArrayList<Node> tree)
    {
        Node right = new Node();
        Node left = new Node();
        Node root = new Node();
        left = tree.get(tree.size()-1);                     //get the Last element of the tree, so the element with less frequency
        right = tree.get(tree.size()-2);                    //get the second element with less frequency in the tree
        root = createRoot(root, left, right);               //Select the two elements with lower frequencies in the tree and generate a new element, a mix between the two.
        tree.remove(tree.size()-1);                         //remove the two last elements of the tree
        tree.remove(tree.size()-1);         
        tree.add(root);                                     //add the mixed element
        tree = bubbleSortTree(tree);                        //sort the tree
        
        return tree;        
    }
    
    public ArrayList<Node> binaryTree(ArrayList<Node> array)
    {
        int i = 0, sum = 0;
        ArrayList<Node> newArray = new ArrayList<>();
        Node root =  new Node();
        
        for(i = 0; i < array.size(); i++)       
        {
            Node node = new Node();                         
            node.setLetter(array.get(i).getLetter());
            node.setNum(array.get(i).getNum());
            node.setAux(0);
            newArray.add(node);                             //Create a new Array of nodes  
        }
        
        for(i = 0; i < array.size(); i++)
            sum  = sum + array.get(i).getNum();
        
        while(newArray.size() > 2)
            newArray = generateTree(newArray);              //Design the tree with each node like root pointing to node left and right, until left just two nodes in the tree 
        
        root.setLetter(newArray.get(0).getLetter() + newArray.get(1).getLetter()); //Create the principal node of the tree pointing to  the other two that were already created
        root.setNum(newArray.get(0).getNum() + newArray.get(1).getNum());
        root.setLeft(newArray.get(0));
        root.setRight(newArray.get(1));
        newArray.add(root);
        newArray.remove(0);
        newArray.remove(0);
        generateBinaries(newArray.get(0), "", "");      //Traverse the tree setting the binary number of each node
        /*for(i = 0; i < newArray.size(); i++)
        	System.out.println(newArray.get(i).getBinarie());*/

        return newArray;
    }
    
    public String getChar(Node n, char letter)                      //Recursion: stops only when to find the letter in the tree and return your correspondent binary.
    {
        String aux = null;
        if(n != null && aux == null)
        {
            if(n.getLetter().equals(Character.toString(letter)))
            {
                aux =  n.getBinarie();
                return aux;
            }
            else
            {
                aux = getChar(n.getLeft(), letter);
                if(aux == null)
                    aux = getChar(n.getRight(), letter);
            }
        }
        return aux;
    }
    
    public String writeCodeMessage(ArrayList<Node> array)                           //Translate the original message to binaries, using the binaries saved in the tree.
    {
        String message = getMessage(), codeMessage = "";
        for(int i = 0; i < message.length(); i++)                                   //Get char by char of the original message and change to the binary correspondent
            codeMessage = codeMessage +" "+getChar(array.get(0), message.charAt(i));
        
        //System.out.println("code message:" + codeMessage);
        codeMessage = codeMessage.trim();
        return codeMessage;
    }
    
    public void writeInFile(String codeMessage) throws FileNotFoundException, IOException       //Write the binary message on the file.
    {
        OutputStream os = new FileOutputStream("codeMessage.txt");
        OutputStreamWriter osw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(osw);

        bw.write(codeMessage);
        bw.newLine();
        bw.close();
    }

    public void readFileInput() throws IOException, ClassNotFoundException {
        FileReader fileReader = new FileReader("fileMessage.txt");
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line;
        text = "";

        while((line = bufferedReader.readLine()) != null){
            text += line;
        }
        bufferedReader.close();
    }
    
}