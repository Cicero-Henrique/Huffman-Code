package Huffman_Java;


public class Root 
{
    private Node left = new Node();
    private Node right = new Node();
    
    public Node getRight() {return right;}
    public Node getLeft() {return left;}

    public void setRight(Node right) {this.right = right;}
    public void setLeft(Node left) {this.left = left;}
    
}
