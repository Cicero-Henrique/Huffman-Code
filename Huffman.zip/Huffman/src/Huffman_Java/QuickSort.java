package Huffman_Java;

import java.io.IOException;
import java.util.ArrayList;


public class QuickSort 
{
    public ArrayList first(int[] array) throws IOException 
    {
        HuffmanCode hc = new HuffmanCode();
        ArrayList<Node> finalArray = new ArrayList();
        finalArray  = hc.inputLetters(array);
        /*for(int  j = 0; j < finalArray.size(); j++)
        {
            System.out.println("Letter: "+ finalArray.get(j).getLetter() + "- Num: " + finalArray.get(j).getNum());
        }
        System.out.println("PRINTOU ");*/
        
        quickSort(finalArray, 0, finalArray.size()-1);
        for (int i = 0; i < finalArray.size(); i++){
            System.out.println(finalArray.get(i).getLetter());
        }
        System.out.println("\\ACABOU O QUICK");
        return finalArray;
    }

    private static void quickSort(ArrayList<Node> array, int inicio, int fim) 
    {
        if (inicio < fim) 
        {
            int pivotPosition = separar(array, inicio, fim);
            quickSort(array, inicio, pivotPosition - 1);
            quickSort(array, pivotPosition + 1, fim);
        }
    }

    private static int separar(ArrayList<Node> array, int inicio, int fim) 
    {
        int pivo = array.get(inicio).getNum();
        int i = inicio + 1, f = fim;
        while (i <= f) 
        {
            if (array.get(i).getNum() <= pivo) 
                i++;
            else if (pivo < array.get(f).getNum()) 
                f--;
            else 
            {
                Node troca  = new Node();
                troca = array.get(i);
                array.set(i, array.get(f));
                array.set(f, troca);
                i++;
                f--;
            }
        }
        array.set(inicio, array.get(f));
        array.set(f, array.get(pivo));
        return f;
    }

}
