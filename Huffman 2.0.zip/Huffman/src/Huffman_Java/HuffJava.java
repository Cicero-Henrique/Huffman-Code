
package Huffman_Java;

import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Cícero
 */
public class HuffJava 
{
    public static void main(String[] args) throws IOException 
    {
        HuffmanCode hc = new HuffmanCode();
        ArrayList<Node> array = new ArrayList();
        array = hc.generateArray();
        array = hc.binaryTree(array);
        String message = hc.writeCodeMessage(array);
        hc.writeInFile(message);
    }
    
}
