package Huffman_Java;
// MISSISSIPI RIVER

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;


public class HuffmanCode 
{
    
    public String getMessage()
    {
        String text = "MISSISSIPPI RIVER";
        return text;
    }

    public int[] countLetters(String message) //This function searches in the 26 Letters and space and counts how many times each character happened in the String
    {
        int[] letters = new int[27];
        int i = 0;
        for(i = 0; i < 26; i++)
            letters[i] = 0;
        
        message = message.toUpperCase();
        for (i = 0; i < message.length(); i++) 
        {
            switch (message.charAt(i)) 
            {
                case 'A':
                    letters[0] = letters[0] + 1;
                    break;
                case 'B':
                    letters[1] = letters[1] + 1;
                    break;
                case 'C':
                    letters[2] = letters[2] + 1;
                    break;
                case 'D':
                    letters[3] = letters[3] + 1;
                    break;
                case 'E':
                    letters[4] = letters[4] + 1;
                    break;
                case 'F':
                    letters[5] = letters[5] + 1;
                    break;
                case 'G':
                    letters[6] = letters[6] + 1;
                    break;
                case 'H':
                    letters[7] = letters[7] + 1;
                    break;
                case 'I':
                    letters[8] = letters[8] + 1;
                    break;
                case 'J':
                    letters[9] = letters[9] + 1;
                    break;
                case 'K':
                    letters[10] = letters[10] + 1;
                    break;
                case 'L':
                    letters[11] = letters[11] + 1;
                    break;
                case 'M':
                    letters[12] = letters[12] + 1;
                    break;
                case 'N':
                    letters[13] = letters[13] + 1;
                    break;
                case 'O':
                    letters[14] = letters[14] + 1;
                    break;
                case 'P':
                    letters[15] = letters[15] + 1;
                    break;
                case 'Q':
                    letters[16] = letters[16] + 1;
                    break;
                case 'R':
                    letters[17] = letters[17] + 1;
                    break;
                case 'S':
                    letters[18] = letters[18] + 1;
                    break;
                case 'T':
                    letters[19] = letters[19] + 1;
                    break;
                case 'U':
                    letters[20] = letters[20] + 1;
                    break;
                case 'V':
                    letters[21] = letters[21] + 1;
                    break;
                case 'X':
                    letters[22] = letters[22] + 1;
                    break;
                case 'W':
                    letters[23] = letters[23] + 1;
                    break;
                case 'Y':
                    letters[24] = letters[24] + 1;
                    break;
                case 'Z':
                    letters[25] = letters[25] + 1;
                    break;
                case ' ':
                    letters[26] = letters[26] + 1;
                    break;
            }
        }
        return letters;
    }
    
    public ArrayList inputLetters(int[] array) //This function receives the array with the frequencies of each letter, create a Node and save in the array of nodes
    {
        int i  = 0;
        ArrayList<Node> arrayList = new ArrayList();
        for(char c = 'A'; c <= 'Z'; c++)
        {
            Node n = new Node();
            n.setLetter(Character.toString(c));
            n.setNum(array[i]);
            arrayList.add(n);
            i++;
        }
        Node n = new Node();
        n.setLetter(Character.toString(' '));
        n.setNum(array[26]);
        arrayList.add(n);
        return arrayList;
    }
    
    public ArrayList bubbleSort(int[] array) //Sort the array with all letters. Is working now but I'm changing to QuickSort. 
    {
        ArrayList<Node> finalArray = new ArrayList();
        finalArray  = inputLetters(array);
        int n = finalArray.size();
        Node temp;
        
        for (int i = 0; i < n; i++) 
        {
            for (int j = 1; j < (n - i); j++) 
            {
                if (finalArray.get(j-1).getNum() < finalArray.get(j).getNum()) 
                {
                    temp = finalArray.get(j-1);
                    finalArray.set(j-1, finalArray.get(j));
                    finalArray.set(j, temp);
                }
            }
        }
        return finalArray;
    }
    
    public ArrayList bubbleSortTree(ArrayList<Node> array) // Sort the array of nodes 
    {
        Node temp;
        for (int i = 0; i < array.size(); i++) 
        {
            for (int j = 1; j < (array.size() - i); j++) 
            {
                if (array.get(j-1).getNum() < array.get(j).getNum()) 
                {
                    temp = array.get(j-1);
                    array.set(j-1, array.get(j));
                    array.set(j, temp);
                }
            }
        }
        return array;
    }
    
    public ArrayList decreaseArray(ArrayList<Node> bigArray) // Search in the array and remove all elements that don't occur in the String
    {
    	int i = 0;
    	ArrayList<Node> shortArray = new ArrayList();
        for(i = 0; i < bigArray.size(); i++)
        {
            if(bigArray.get(i).getNum() != 0)
                shortArray.add(bigArray.get(i));
        }
        return shortArray;
    }

    public ArrayList generateArray() throws IOException 
    {
        int[] arrayNumbers = new int[26];
        int i = 0;
        String message = getMessage();                              //Get the String on the file but now I'm using "mississippi river" just for tests 
        ArrayList<Node> bigArray = new ArrayList();                 
        arrayNumbers = countLetters(message);                       //Array of Integers with the frequency of all letters
        QuickSort qs = new QuickSort();
        
        bigArray  = inputLetters(arrayNumbers);
        qs.sort(bigArray, 0, bigArray.size() -1);                        //Sort the array of Integers
        bigArray = decreaseArray(bigArray);                         //Leaves only the letters that occur in the String
        
        return bigArray;
    }
    
    public Node createRoot(Node r, Node l1, Node l2)
    {
        r.setLetter(l1.getLetter() + l2.getLetter());
        r.setNum(l1.getNum() + l2.getNum());
        l1.setAux(0);
        l2.setAux(1);
        r.setLeft(l1);
        r.setRight(l2);
        return r;
    }
    
    public static void generateBinaries(Node n, String side, String sc) 
    {    
        if(n!= null)
        {
            n.setBinarie((n.getBinarie() +sc + side).trim());
            if(n.getLetter().length() == 1)
                System.out.println(n.getLetter() + "-" + n.getNum()+"-"+n.getBinarie()+";");
            generateBinaries(n.getLeft(), "0", n.getBinarie());
            generateBinaries(n.getRight(), "1", n.getBinarie());
        }
    }
    
    public ArrayList<Node> generateTree(ArrayList<Node> tree)
    {
        Node right = new Node();
        Node left = new Node();
        Node root = new Node();
        left = tree.get(tree.size()-1);                     //get the Last element of the tree, so the element with less frequency
        right = tree.get(tree.size()-2);                    //get the second element with less frequency in the tree
        root = createRoot(root, left, right);               //Select the two elements with lower frequencies in the tree and generate a new element, a mix between the two.
        tree.remove(tree.size()-1);                         //remove the two last elements of the tree
        tree.remove(tree.size()-1);         
        tree.add(root);                                     //add the mixed element
        tree = bubbleSortTree(tree);                        //sort the tree
        
        return tree;        
    }
    
    public ArrayList binaryTree(ArrayList<Node> array)
    {
        int i = 0, sum = 0;
        ArrayList<Node> newArray = new ArrayList();
        Node root =  new Node();
        
        for(i = 0; i < array.size(); i++)       
        {
            Node node = new Node();                         
            node.setLetter(array.get(i).getLetter());
            node.setNum(array.get(i).getNum());
            node.setAux(0);
            newArray.add(node);                             //Create a new Array of nodes  
        }
        
        for(i = 0; i < array.size(); i++)
            sum  = sum + array.get(i).getNum();
        
        while(newArray.size() > 2)
            newArray = generateTree(newArray);              //Design the tree with each node like root pointing to node left and right, until left just two nodes in the tree 
        
        root.setLetter(newArray.get(0).getLetter() + newArray.get(1).getLetter()); //Create the principal node of the tree pointing to  the other two that were already created
        root.setNum(newArray.get(0).getNum() + newArray.get(1).getNum());
        root.setLeft(newArray.get(0));
        root.setRight(newArray.get(1));
        newArray.add(root);
        newArray.remove(0);
        newArray.remove(0);
        generateBinaries(newArray.get(0), "", "");          //Traverse the tree setting the binary number of each node
        
        return newArray;
    }
    
    public String getChar(Node n, char letter)                      //Recursion: stops only when to find the letter in the tree and return your correspondent binary.
    {
        String aux = null;
        if(n != null && aux == null)
        {
            if(n.getLetter().equals(Character.toString(letter)))
            {
                aux =  n.getBinarie();
                return aux;
            }
            else
            {
                aux = getChar(n.getLeft(), letter);
                if(aux == null)
                    aux = getChar(n.getRight(), letter);
            }
        }
        return aux;
    }
    
    public String writeCodeMessage(ArrayList<Node> array)                           //Translate the original message to binaries, using the binaries saved in the tree.
    {
        String message = getMessage().toUpperCase(), codeMessage = "";
        for(int i = 0; i < message.length(); i++)                                   //Get char by char of the original message and change to the binary correspondent
            codeMessage = codeMessage +" "+getChar(array.get(0), message.charAt(i));
        
        System.out.println("code message:" + codeMessage);
        codeMessage = codeMessage.trim();
        return codeMessage;
    }
    
    public void writeInFile(String codeMessage) throws FileNotFoundException, IOException       //Write the binary message on the file.
    {
        OutputStream os = new FileOutputStream("codeMessage.txt");
        OutputStreamWriter osw = new OutputStreamWriter(os);
        BufferedWriter bw = new BufferedWriter(osw);

        bw.write(codeMessage);
        bw.newLine();
        bw.close();
    }
    
}